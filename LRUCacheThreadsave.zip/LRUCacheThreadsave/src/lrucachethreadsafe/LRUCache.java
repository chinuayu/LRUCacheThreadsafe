/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lrucachethreadsafe;

import lrucachethreadsafe.utils.ReaderWriter;
import lrucachethreadsafe.utils.DiscHelper;
import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.UUID;

/**
 *
 * @author Ayushi
 * @param <K> KeyType
 * @param <V> ValueType
 */
public class LRUCache<K, V> extends ReaderWriter {
    private static final boolean DEBUG = false;
    
    private final File PATH;
    private final int CAPACITY;
    
//    private final Object dataSetSync = new Object();
    private final Set<K> dataSet;
    
    private LinkedHashMap<K, V> cache;
    
    public LRUCache(int capacity) {
        this(capacity, "");
    }
    
    public LRUCache(int capacity, String path) {
        CAPACITY = capacity;
        
        String uniqueID = UUID.randomUUID().toString();
        
        if(path != null && path.length() > 0)
            PATH = new File(path + File.separator + uniqueID);
        else
            PATH = new File(uniqueID);
        
        PATH.mkdirs();
        PATH.mkdir();
        
        System.out.println("Disc cache folder: " + PATH);
        
        dataSet = new HashSet<>();
        cache = new LinkedHashMap<>(CAPACITY);
    }
    
    public V get(K key) throws Exception {
        if(DEBUG) System.out.println("Get key: " + key);
        
        if(!dataSet.contains(key)) {
            //data does not exist in cache
            return null;
        }
        
        //check for data in mem cache
        preRead();
        V v = cache.get(key);
        postRead();
        
        Exception e = null;
        if(v == null) {
            //data was not in mem cache
            //fallback to disc
            
            //get exclusive write access then update
            preWrite();
            try {
                v = (V) DiscHelper.read(PATH, key);
                cache.put(key, v);
            } catch (IOException | ClassNotFoundException ex) {
                v = null;
                e = ex;
            }
            postWrite();
        }
        
        if(e != null)
            throw e;
        
        return v;
    }
    
//    public void put(K key, V value) throws IOException {
//        if(DEBUG) System.out.println("Put key: " + key);
//        
//        if(dataSet.contains(key)) {
//            //data already present
//            
//            //get exclusive write access then update
//            preWrite();
//            cache.remove(key);
//            DiscHelper.write(PATH, key, value);
//            postWrite();
//        } else {
//            DiscHelper.write(PATH, key, value);
//
//            synchronized (dataSetSync) {
//                dataSet.add(key);
//            }
//        }
//    }
    
    
    public synchronized void put(K key, V value) throws IOException {
        if(DEBUG) System.out.println("Put key: " + key);
       
        if(dataSet.contains(key)) {
            //data already present
            
            //get exclusive write access then update
            preWrite();
            cache.remove(key);
            DiscHelper.write(PATH, key, value);
            postWrite();
        } else {
            DiscHelper.write(PATH, key, value);
            
            dataSet.add(key);   
        }
    }
    
    @Override
    protected void finalize() throws Throwable {
        DiscHelper.deleteDirectory(PATH);
        
        super.finalize();
    }
}
