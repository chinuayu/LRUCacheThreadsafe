/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lrucachethreadsafe.dataset;

import java.io.Serializable;

/**
 *
 * @author Ayushi
 */
public class Data implements Serializable {
    String value;
    
    public Data(String s) {
        value = s;
    }

    @Override
    public boolean equals(Object obj) {
        return value.equals(((Data)obj).value);
    }
}
