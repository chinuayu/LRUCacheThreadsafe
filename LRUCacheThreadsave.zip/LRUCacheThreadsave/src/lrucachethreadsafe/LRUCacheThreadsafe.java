/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lrucachethreadsafe;


import java.io.IOException;
import lrucachethreadsafe.dataset.Data;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ayushi
 */
public class LRUCacheThreadsafe {

    private static String s() {
        String s = (int)(Math.random()*10.0) + "";
        return s;
    }
    
    private static boolean running = true;
    
    private static LRUCache<String, Data> cache;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        cache = new LRUCache<>(5);
        try {
            cache.put("0",new Data("abc"));
             cache.put("1",new Data("abc")); cache.put("2",new Data("abc")); cache.put("3",new Data("abc")); cache.put("4",new Data("abc"));
              cache.put("5",new Data("abc")); cache.put("6",new Data("abc")); cache.put("7",new Data("abc")); cache.put("8",new Data("abc"));
               cache.put("9",new Data("abc")); cache.put("10",new Data("abc"));
               System.out.println(cache.get("11"));
        } catch (IOException ex) {
            Logger.getLogger(LRUCacheThreadsafe.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            Logger.getLogger(LRUCacheThreadsafe.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        Thread reader = new Thread(new Runnable() {

            @Override
            public void run() {
                while(running) {
//                    System.out.println("reader: start");
                    try {
//                        Thread.sleep(10);
                        System.out.println("" + cache.get(s()));
                    } catch(Exception e) {
                        e.printStackTrace();
                    }
//                    System.out.println("reader: end");
                }

                System.out.println("reader END END END");
            }
        });

        Thread writer = new Thread(new Runnable() {

            @Override
            public void run() {
                while(running) {

//                    System.out.println("writer: start");
                    try {
//                        Thread.sleep(10);
                        cache.put(s(), new Data(s()));
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
//                    System.out.println("writer: end");
                    
                }

                System.out.println("writer END END END");
            }
        });

        Thread wait = new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(LRUCacheThreadsafe.class.getName()).log(Level.SEVERE, null, ex);
                }

                running = false;

                System.out.println("END END END");
            }
        });
            
            
        wait.start();
        writer.start();
        reader.start();
        
        try {
            wait.join();
            writer.join();
            reader.join();
        } catch(Exception e) {
            e.printStackTrace();
        }
        
//            try {
//            LRUCache<String, Data> s = new LRUCache<>(20);
//            s.put("a", new Data("yoyoa"));
//            s.put("b", new Data("yoyob"));
//            s.put("c", new Data("yoyoc"));
//            s.put("a", new Data("yoyoa"));
            
//            s.put(new Data("a"), new Data("yoyoa"));
//            s.put(new Data("b"), new Data("yoyoa"));
//            s.put(new Data("c"), new Data("yoyoa"));
//            s.put(new Data("d"), new Data("yoyoa"));
//            s.put(new Data("a"), new Data("yoyoa"));
            
//            System.out.println(s.get("a"));
//            System.gc();
//        } catch (IOException ex) {
//            Logger.getLogger(LRUCacheThreadsafe.class.getName()).log(Level.SEVERE, null, ex);
//        } catch (ClassNotFoundException ex) {
//            Logger.getLogger(LRUCacheThreadsafe.class.getName()).log(Level.SEVERE, null, ex);
//        }
    }
}