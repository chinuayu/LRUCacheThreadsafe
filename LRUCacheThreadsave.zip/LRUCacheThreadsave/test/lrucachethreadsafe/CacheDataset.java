/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lrucachethreadsafe;

import java.security.SecureRandom;
import java.util.Random;
import lrucachethreadsafe.dataset.Data;
import org.testng.annotations.DataProvider;

/**
 *
 * @author Ayushi
 */
public class CacheDataset {
    public static final int CAPACITY = 10;
    
    public static final int DATASET_SIZE = 100;
    
    public static final int THREAD_POOL_SIZE = 10;
    
    /**
    * Data Provider for testing cache input 1
    *
    * @return data
    */
    @DataProvider
    public static Object[][] inbuildDataType() {
        return new Object[][] { 
            { "5", "5" }, 
            { "10", "10" }, 
            { "20", "20" },
            { "40", "40" },
            { "80", "80" },
        };
    }
    
    @DataProvider
    public static Object[][] inbuildDataTypeLarge() {
        Object[][] b = new Object[DATASET_SIZE][2];
        for(int i = 0; i < DATASET_SIZE; i++) {
            b[i][0] = generateRandom((int)(Math.random()*10) + 1);
            b[i][1] = generateRandom((int)(Math.random()*10) + 1);
        }
        return b;
    }
    
    /**
    * Data Provider for testing cache input 2
    *
    * @return data
    */
    @DataProvider
    public static Object[][] customDataType() {
        return new Object[][] { 
            { "5", new Data("5") }, 
            { "10", new Data("10") }, 
            { "20", new Data("20") },
            { "40", new Data("40") },
            { "80", new Data("80") },
        };
    }
    
    @DataProvider
    public static Object[][] customDataTypeLarge() {
        Object[][] b = new Object[DATASET_SIZE][2];
        for(int i = 0; i < DATASET_SIZE; i++) {
            b[i][0] = generateRandom((int)(Math.random()*10) + 1);
            b[i][1] = new Data(generateRandom((int)(Math.random()*10) + 1));
        }
        return b;
    }
    
    
    /**
     * random string generators
     */
    private static final String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    public static String generateRandom(int length) {
        Random random = new SecureRandom();
        if (length <= 0) {
            length = 10;
        }

        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            sb.append(characters.charAt(random.nextInt(characters.length())));
        }

        return sb.toString();
    }
}
