/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lrucachethreadsafe.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/**
 *
 * @author Ayushi
 */
/**
* 
* Disc helper functions
*/
public class DiscHelper {
    
    public static void write(File path, Object key, Object value) throws FileNotFoundException, IOException {
        if(value instanceof Serializable) {
            FileOutputStream f = new FileOutputStream(fileFromObject(path, key));  
            ObjectOutputStream out = new ObjectOutputStream(f);  
            out.writeObject(value);  
            out.flush();
            out.close();  
            f.close();
        } else {
            throw new IOException("Class not serializable.");  
        }
    }
    
    public static Object read(File path, Object key) throws FileNotFoundException, IOException, ClassNotFoundException {
        FileInputStream f = new FileInputStream(fileFromObject(path, key));
        ObjectInputStream in = new ObjectInputStream(f);
        Object v = in.readObject();
        in.close();  
        
        return v;
    }
    
    private static File fileFromObject(File path, Object key) {
        return new File(path, key.hashCode()+"");
    }
    
    public static boolean deleteDirectory(File path) {
        if( path.exists() ) {
            File[] files = path.listFiles();
            if(files != null) {
                for(File f: files) {
                   if(f.isDirectory()) {
                     deleteDirectory(f);
                   } else {
                     f.delete();
                   }
                }
            }
        }
        return( path.delete() );
    }
}
