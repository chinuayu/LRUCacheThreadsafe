/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lrucachethreadsafe;

import java.io.IOException;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

/**
 *
 * @author Ayushi
 */
public class CacheTest_Basic_Multithread {
    public LRUCache<String, String> cache;
    
    @BeforeClass
    public void init() {
        System.out.println("Basic cache test");
        System.out.println("cache created");
        cache = new LRUCache<>(CacheDataset.CAPACITY);
    }
    
    long time;
    @BeforeTest
    public void bt() {
        time = System.currentTimeMillis();
    }
    
    @AfterTest
    public void at() {
        time = System.currentTimeMillis() - time;
        System.out.println("CacheTest_Basic_Multithread Execution time: " + time);
    }
    
    @Test(dataProviderClass = CacheDataset.class, 
            dataProvider = "inbuildDataType", 
            threadPoolSize = 2)
    public void testCache(String a, String b) throws IOException, Exception {
        cache.put(a, b);
        Assert.assertEquals(cache.get(a), b);
    }
    
    @Test(dataProviderClass = CacheDataset.class, 
            dataProvider = "inbuildDataTypeLarge", 
            threadPoolSize = CacheDataset.THREAD_POOL_SIZE)
    public void testCacheLarge(String a, String b) throws IOException, Exception {
        cache.put(a, b);
        Assert.assertEquals(cache.get(a), b);
    }
}
