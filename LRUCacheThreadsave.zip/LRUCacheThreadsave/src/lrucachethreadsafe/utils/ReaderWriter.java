/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lrucachethreadsafe.utils;

import java.util.concurrent.Semaphore;

/**
 *
 * @author Ayushi
 */
public abstract class ReaderWriter {
    private static boolean DEBUG = false;
    
    private int readersCount;                  // init to 0; number of readers currently accessing resource
    private final Semaphore readersAccess = new Semaphore(1);      // for syncing changes to shared variable readersCount
    
    private final Semaphore dataAccess = new Semaphore(1);       // controls access (read/write) to the resource
    
    private final Semaphore queue = new Semaphore(1);         // FAIRNESS: preserves ordering of requests (signaling must be FIFO)

    protected void preWrite() {
        if(DEBUG) System.out.println("preWrite: start");
        
        queue.acquireUninterruptibly();           // wait in line to be serviced
        
        dataAccess.acquireUninterruptibly();         // request exclusive access to resource
        
        queue.release();           // let next in line be serviced
        
        if(DEBUG) System.out.println("preWrite: end");
    }

    protected void postWrite() {
        if(DEBUG) System.out.println("postWrite: start");
        
        dataAccess.release();         // release resource access for next reader/writer
        
        if(DEBUG) System.out.println("postWrite: end");
    }

    protected void preRead() {
        if(DEBUG) System.out.println("preRead: start");
        
        queue.acquireUninterruptibly();           // wait in line to be serviced
        readersAccess.acquireUninterruptibly();        // request exclusive access to readersCount
        
        if (readersCount == 0)         // if there are no readers already reading:
            dataAccess.acquireUninterruptibly();     // request resource access for readers (writers blocked)
        readersCount++;                // update count of active readers
        
        queue.release();           // let next in line be serviced
        readersAccess.release();        // release access to readersCount
        
        if(DEBUG) System.out.println("preRead: end");
    }
    
    protected void postRead() {
        if(DEBUG) System.out.println("postRead: start");
        
        readersAccess.acquireUninterruptibly();        // request exclusive access to readersCount
        
        readersCount--;                // update count of active readers
        if (readersCount == 0)         // if there are no readers left:
            dataAccess.release();     // release resource access for all
        
        readersAccess.release();        // release access to readersCount
        
        if(DEBUG) System.out.println("postRead: end");
    }
}